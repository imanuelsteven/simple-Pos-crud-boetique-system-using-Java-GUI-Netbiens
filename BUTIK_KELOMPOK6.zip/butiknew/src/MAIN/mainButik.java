/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MAIN;

import VIEW.LOGIN;

/**
 *
 * @author steven
 */
public class mainButik {
    public static void main(String[] args) {
        new LOGIN().setVisible(true);
    }
}
